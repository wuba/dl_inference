#!/bin/bash

#tensorflow模型处理逻辑
function tfProcess(){
    input_path=$1
    export_path=$2
    
    #创建TIS模型仓库路径
    CONFIG_DIR=$export_path/$MODEL_NAME
    echo "target config file dir: $CONFIG_DIR"
    MODEL_DIR=$CONFIG_DIR/$VERSION
    echo "target model dir: $MODEL_DIR"

    if [ ! -d $MODEL_DIR ]; then
        mkdir -p $MODEL_DIR
    fi
    
    #检测savedmodel模型完整性
    modelPb=`find $input_path -type f -name "*.pb"`
    if [ ! -f "$modelPb" ]; then
        echo "error : not exist savedmodel file, please check your model"
        exit 1
    fi
    modelVar=`find $input_path  -name "variables"`
    if [ ! -d "$modelVar" ]; then
        echo "error : not exist variables fold, please check your model"
        exit 1
    fi

    target_dir=`dirname $modelPb`

    ########trt convert
    echo "trt convert process begin======"
    python3 -u ./tf_to_plan.py --config $CONFIG_FILE_URL --in_path $target_dir --out_model_dir $MODEL_DIR --out_config_dir $CONFIG_DIR --name $MODEL_NAME 
    echo "trt convert process end======"
}

tfProcess $1 $2
