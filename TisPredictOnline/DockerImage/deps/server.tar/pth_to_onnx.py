import tensorrt as trt
import torch
import subprocess
import os
import sys
import argparse
import json
import onnx
from types import FunctionType
from common  import *
from model import *
from onnx_to_plan import Onnx2PlanConvertor
from convert_config_file import ConfigFileGenerator

logging.basicConfig(level=logging.DEBUG,
                    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S")
logger = logging.getLogger(__name__)

class Pth2PlanConvertor(object):
    def __init__(self, opt):
        self.opt = opt
        ##用于onnx模型转换为plan模型
        self.onnx_convert = Onnx2PlanConvertor(opt)
        ##用于生成TIS部署plan模型所需配置文件
        self.config_file_generator = ConfigFileGenerator(opt)

    def load_model(self):
        load_model_exists = ('load_model' in locals() or 'load_model' in globals()) and isinstance(load_model, FunctionType)
        if (load_model_exists):
            self.model = load_model()
        else:
            self.model = torch.load('model.pth', map_location="cuda")
        self.device = torch.device("cuda")
        self.model.to(self.device)
        self.model.eval()

    def convert_to_onnx(self):
        self.load_model()
        self.opt.onnx_path = self.opt.out_model_dir + "/model.onnx"
        input_name = self.opt.input_name
        output_name = self.opt.output_names
        input = torch.autograd.Variable(torch.randn(self.opt.input_shape)).cuda()
        torch.onnx.export(self.model, input, self.opt.onnx_path, input_names=input_name, output_names=output_name, verbose=True, opset_version=11)
        test = onnx.load(self.opt.onnx_path)
        onnx.checker.check_model(test)
        print("==> Passed")
        print("onnx model finished: model.onnx")

    def run(self):
        self.convert_to_onnx()
        self.onnx_convert.convert_onnx_to_plan()
        self.config_file_generator.generate_config_file()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", help="The model metadata describe file")
    parser.add_argument("--in_path", help="The source model path")
    parser.add_argument("--out_model_dir", help="The trt model path")
    parser.add_argument("--out_config_dir", help="The trt model config file  path")
    parser.add_argument("--name", help="The trt model name")
    opt = parser.parse_args()
    if not check_config(opt):
        sys.exit(1)
    else:
        convertor = Pth2PlanConvertor(opt)
        convertor.run()
