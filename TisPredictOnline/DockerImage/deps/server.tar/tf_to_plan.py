import tensorrt as trt
import tensorflow as tf
import subprocess
import os
import argparse
import json
import onnx
from types import FunctionType
import logging
import keras2onnx
from common  import *
from onnx_to_plan import Onnx2PlanConvertor
from convert_config_file import ConfigFileGenerator

#### 用于将tensorflow:savedmodel格式模型转换为TensorRT模型

logging.basicConfig(level=logging.DEBUG,
                    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S")
logger = logging.getLogger(__name__)

class Tf2PlanConvertor(object):
    def __init__(self, opt):
        ##配置总线
        self.opt=opt
        ##用于onnx模型转换为plan模型
        self.onnx_convert = Onnx2PlanConvertor(opt)
        ##用于生成TIS部署plan模型所需配置文件
        self.config_file_generator = ConfigFileGenerator(opt)
 
    def tf_to_onnx(self):
        self.opt.onnx_path = self.opt.out_model_dir + "/model.onnx"
        logger.debug("onnx model output path:" + self.opt.out_model_dir)
        logger.debug("begin savedmodel -> onnx convert")
        order = "python -m tf2onnx.convert --saved-model " + self.opt.in_path + " --opset 11 --output " +  self.opt.onnx_path
        logger.debug(order)
        status,output = subprocess.getstatusoutput(order)
        logger.debug("end savedmodel -> onnx convert")
        
    def run(self):
        self.tf_to_onnx()
        self.onnx_convert.convert_onnx_to_plan()
        self.config_file_generator.generate_config_file()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", help="The model metadata describe file")
    parser.add_argument("--in_path", help="The source model path")
    parser.add_argument("--out_model_dir", help="The trt model path")
    parser.add_argument("--out_config_dir", help="The trt model config file  path")
    parser.add_argument("--name", help="The trt model name")
    opt = parser.parse_args()
    if not check_config(opt):
        sys.exit(1)
    else:
        convertor = Tf2PlanConvertor(opt)
        convertor.run()
