#!/python
import argparse
import json
import os
import logging

logging.basicConfig(level=logging.DEBUG,
                    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S")
logger = logging.getLogger(__name__)

CONFIG_TYPE = {
    "bool": "TYPE_BOOL",
    "byte": "TYPE_UINT8",
    "uint8": "TYPE_UINT8",
    "char": "TYPE_INT8",
    "shrot": "TYPE_INT16",
    "int": "TYPE_INT32",
    "long": "TYPE_INT64",
    "float": "TYPE_FP32",
    "double": "TYPE_FP64",
    "string" : "TYPE_STRING"
}


TIS_DTYPE = {
        "DT_FLOAT" : "TYPE_FP32",
        "DT_INT32" : "TYPE_INT32",
        "DT_STRING" : "TYPE_STRING",
        "DT_INT64" : "TYPE_INT64",
        "DT_BOOL" : "TYPE_BOOL",
        "DT_UINT8" : "TYPE_UINT8",
        "DT_UINT16" : "TYPE_UINT16",
        "DT_UINT32" : "TYPE_UINT32",
        "DT_UINT64" : "TYPE_UINT64",
        "DT_INT8" : "TYPE_INT8",
        "DT_INT16" : "TYPE_INT16",
        "DT_HALF" : "TYPE_FP16",
        "DT_DOUBLE" : "TYPE_FP64"
}


TENSOR = """\
  {{
    name: "{name}",
    dims: {dims},
    data_type: {data_type}
  }}\
"""


TENSOR_RESHAPE = """\
  {{
    name: "{name}",
    dims: {dims},
    data_type: {data_type},
    reshape: {{ shape: {reshape} }}
  }}\
"""

INPUT_MAP = """\
      input_map {{
         key: "{input_tensor_name}"
         value: "{input_tensor_name}"
      }}\
"""

OUTPUT_MAP = """\
      output_map {{
         key: "{output_tensor_name}"
         value: "{output_tensor_name}"
      }}\
"""

MODEL_STEP = """\
    {{
      model_name: "{sub_model_name}"
      model_version: -1
{input_map}
{output_map}
    }}\
"""

ENSEMBLE_CONFIG_PBTXT = """\
name: "{name}"
platform: "ensemble"
max_batch_size: {max_batch_size}
input {input}
output {output}
ensemble_scheduling {{
  step {model_step}
}}\
"""

CONFIG_PBTXT = """\
name: "{name}"
platform: "{platform}"
version_policy: {{ all {{ }} }}
max_batch_size: {max_batch_size}
input {input}
output {output}
instance_group [
  {{
    count: {instances}
    kind: KIND_GPU
    gpus: {gpus}
  }}
]\
"""

CONFIG_PBTXT_BATCH = """\
name: "{name}"
platform: "{platform}"
version_policy: {{ all {{ }} }}
max_batch_size: {max_batch_size}
input {input}
output {output}
instance_group [
  {{
    count: {instances}
    kind: KIND_GPU
    gpus: {gpus}
  }}
]
dynamic_batching {{
  preferred_batch_size: [{max_batch_size}],
  preserve_ordering: true
}}\
"""


DIMS = "dims"
NAME = "name"
DATA_TYPE = "data_type"
NODE_NAME = "node_name"

def check_config(opt):
    if not os.path.exists(opt.config):
        logger.error("config file <" + opt.config + "> is not exists")
        return False
    with open(opt.config, 'r',encoding='utf8') as fp:
        json_data = json.load(fp)
        logger.debug(json_data)
        input_data = json_data.get("input")
        output_data = json_data.get("output")
        batch_size = json_data.get("batch_size")
        if batch_size == None:
            logger.error("config file has not batch_size config")
            return False
        if input_data == None or len(input_data) == 0:
            logger.error("config file has not input config")
            return False
        if output_data == None or len(output_data) == 0:
            logger.error("config file has not output config")
            return False
        output_names = []
        for ouput in output_data:
            output_names.append(ouput.get("node_name"))
        opt.output_names = output_names
        opt.batch_size = batch_size
        opt.input_data = input_data
        opt.output_data = output_data
        opt.input_name = input_data[0].get("node_name")
        opt.input_shape = input_data[0].get("dims")
        if opt.input_shape == None:
            logger.error("input config has not dims")
            return False
    return True


def data_def_dumps(node_def, remove_batch_dim=False):
    data = []
    for node in node_def:
        name = node.get(NAME, None)
        dims = node.get(DIMS, None)
        data_type = node.get(DATA_TYPE, "TYPE_FP32")
        reshape = node.get("reshape", dims)
        if remove_batch_dim is False:
            format_output = TENSOR.format(
                name=name,
                dims=dims,
                data_type=data_type
            )
        else:
            format_output = TENSOR_RESHAPE.format(
                name=name,
                dims=dims,
                data_type=data_type,
                reshape=dims[1:]
            )
        data.append(format_output)
    data = "[\n" + ",\n".join(data) + "\n]"
    return data

def ensemble_input_map_dumps(inputs_def):
    data = []
    for val in inputs_def:
        name = val.get("input_tensor_name", None)
        format_output = INPUT_MAP.format(
          input_tensor_name = name
        )
        data.append(format_output)
    data = "\n".join(data)
    return data

def ensemble_output_map_dumps(outputs_def):
    data = []
    for val in outputs_def:
        name = val.get("output_tensor_name", None)
        format_output = OUTPUT_MAP.format(
          output_tensor_name = name
        )
        data.append(format_output)
    data = "\n".join(data)
    return data

def ensemble_step_def_dumps(step_def):
    data = []
    for step in step_def:
        sub_model = step.get("sub_model_name", None)
        input_maps = step.get("input_maps", None)
        output_maps = step.get("output_maps", None)
        format_output = MODEL_STEP.format(
           sub_model_name=sub_model,
           input_map=ensemble_input_map_dumps(input_maps),
           output_map=ensemble_output_map_dumps(output_maps)
        )
        data.append(format_output)
    data = "[\n" + ",\n".join(data) + "\n  ]"
    return data

def generate_trtis_config(
    graph_name="model*",
    platform="tensorrt_plan",
    inputs_def={},
    outputs_def={},
    max_batch_size=0,
    instances=1,
    gpus=[0],
    delay=80,
    export_path=".",
    verbose=True
):

#    remove_batch_dim = True if platform is "tensorrt_plan" else False
    remove_batch_dim = False
    config_path = "{}/config.pbtxt".format(export_path)
    target = CONFIG_PBTXT
    if (max_batch_size > 0):
        target = CONFIG_PBTXT_BATCH
    config_content = target.format(
        name=str(graph_name),
        platform=str(platform),
        max_batch_size=max_batch_size,
        input=data_def_dumps(inputs_def, remove_batch_dim),
        output=data_def_dumps(outputs_def, remove_batch_dim),
        instances=instances,
        gpus=gpus
    )

    with open(config_path, "w") as cfg:
        cfg.write(config_content)

    if verbose:
        print(config_content)



def generate_trtis_ensemble_config(
    graph_name="model*",
    inputs_def={},
    outputs_def={},
    steps_def={},
    max_batch_size=0,
    export_path=".",
    verbose=True
):

#    remove_batch_dim = True if platform is "tensorrt_plan" else False
    remove_batch_dim = False
    config_path = "{}/config.pbtxt".format(export_path)
    target = ENSEMBLE_CONFIG_PBTXT
    config_content = target.format(
        name=str(graph_name),
        max_batch_size=max_batch_size,
        input=data_def_dumps(inputs_def, remove_batch_dim),
        output=data_def_dumps(outputs_def, remove_batch_dim),
        model_step=ensemble_step_def_dumps(steps_def)
    )

    with open(config_path, "w") as cfg:
        cfg.write(config_content)

    if verbose:
        print(config_content)

if __name__ == "__main__":
    inputs_def = [
        {
            "name": "raw_image",
            "dims": [1],
            "data_type": "TYPE_STRING",
        }
    ]
    input = data_def_dumps(inputs_def)
    print(input)
    steps_def = [
        {
            "sub_model_name": "wzb",
            "input_maps": [
               {"input_tensor_name": "input1"},
               {"input_tensor_name": "input2"}
             ],
             "output_maps": [
               {"output_tensor_name": "output1"},
               {"output_tensor_name": "output2"}
             ]
        },
        {
            "sub_model_name": "lxw",
            "input_maps": [
               {"input_tensor_name": "input1"},
               {"input_tensor_name": "input2"}
             ],
             "output_maps": [
               {"output_tensor_name": "output1"},
               {"output_tensor_name": "output2"}
             ]
        }
    ]
    step = ensemble_step_def_dumps(steps_def)
    print(step)
    generate_trtis_ensemble_config(
        graph_name="model",
        max_batch_size=0,
        inputs_def=inputs_def,
        outputs_def=inputs_def,
        steps_def=steps_def,
    )
 
