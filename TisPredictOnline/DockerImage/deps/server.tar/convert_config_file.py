from common  import *
import os

class ConfigFileGenerator:
    def __init__(self, opt):
        self.opt = opt

    def generate_config_file(self):
        input_data = self.opt.input_data
        output_data = self.opt.output_data
        for i in range(0, len(input_data)):
            input_data[i]["name"] = input_data[i]["node_name"]
            input_data[i]["data_type"] = CONFIG_TYPE[input_data[i]["data_type"]]
        for i in range(0, len(output_data)):
            output_data[i]["name"] = output_data[i]["node_name"]
            output_data[i]["data_type"] = CONFIG_TYPE[output_data[i]["data_type"]]
        generate_trtis_config(
            graph_name=self.opt.name,
            platform="tensorrt_plan",
            inputs_def=input_data,
            outputs_def=output_data,
            max_batch_size=0,
            instances=1,
            gpus=[0],
            export_path=self.opt.out_config_dir,
            verbose=True
        )
