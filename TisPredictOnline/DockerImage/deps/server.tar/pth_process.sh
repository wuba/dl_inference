#!/bin/bash

#pytorch模型处理逻辑
function pthProcess(){
    input_path=$1
    export_path=$2

    #创建TIS模型仓库路径
    CONFIG_DIR=$export_path/$MODEL_NAME
    echo "target config file dir: $CONFIG_DIR"
    MODEL_DIR=$CONFIG_DIR/$VERSION
    echo "target model dir: $MODEL_DIR"

    if [ ! -d $MODEL_DIR ]; then
        mkdir -p $MODEL_DIR
    fi 

    modelPth=`find $input_path  -name model.pth`
    if [ -n "$modelPth" ]; then
	targetDir=`dirname $modelPth`
	echo "currentModelPthPath: '"$modelPth"'"
    else    
	echo "error : not exist model.pth file, please check your model"   
    fi

    pyPackagesReqFile=$targetDir/requirements.txt
    if [ -f "$pyPackagesReqFile" ]; then
        echo "Begin install python packages"
	for pyPackage in `cat $pyPackagesReqFile`
	do
	    pip install $pyPackage -i https://pypi.tuna.tsinghua.edu.cn/simple
	done
    else
        echo "There is no python requirements file "$pyPackagesReqFile
    fi

    cp common.py $targetDir
    cp convert_config_file.py $targetDir
    cp pth_to_onnx.py $targetDir
    cp onnx_to_plan.py  $targetDir
    cd $targetDir
    
    if [ ! -f "model.py" ]; then
        touch model.py
    fi

    echo "trt convert process begin======"
    python3 -u ./pth_to_onnx.py --config $CONFIG_FILE_URL --in_path $targetDir --out_model_dir $MODEL_DIR --out_config_dir $CONFIG_DIR --name $MODEL_NAME
    #python3 -u ./onnx_to_plan.py  ##分开调用，避免显存溢出
    echo "trt convert process end======"
}

pthProcess $1 $2
