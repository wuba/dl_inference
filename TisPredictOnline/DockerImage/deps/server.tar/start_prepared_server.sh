#!/bin/bash

##/workspace 为预处理镜像挂载目录
##原始模型路径
#SOURCE_MODEL_PATH=/workspace/source_model
##转换后trt模型路径
#TARGET_MODEL_PATH=/workspace/source_model
##模型类型 tensorflow or pytorch
#MODEL_TYPE=tensorflow
##模型名称
#export MODEL_NAME=tensorflow-666
##配置文件地址
export CONFIG_FILE_URL=$SOURCE_MODEL_PATH/config.txt
##模型版本号
export VERSION=1

echo "SOURCE_MODEL_PATH:$SOURCE_MODEL_PATH, TARGET_MODEL_PATH:$TARGET_MODEL_PATH, MODEL_TYPE:$MODEL_TYPE, MODEL_NAME:$MODEL_NAME, CONFIG_FILE_URL:$CONFIG_FILE_URL"

#tensorflow模型处理逻辑
function tfModelProcess(){
    echo "tfModelProcess"
    chmod 777 ./tf_process.sh
    ./tf_process.sh $1 $2

}

#pytorch模型处理逻辑
function ptModelProcess(){
    echo "ptModelProcess"
    chmod 777 ./pth_process.sh
    ./pth_process.sh $1 $2
}


#模型处理入口函数，完成模型的转换及配置
function convertModel(){
    sourcePath=$1
    targetPath=$2
    modelType=$3

    if [ "$modelType" == "tensorflow" ]; then
        tfModelProcess $sourcePath $targetPath
    elif [ "$modelType" == "pytorch" ]; then
        ptModelProcess $sourcePath $targetPath
    else
	echo "error:unsupport model type:$modelType"
	exit 1
    fi	
}

#模型处理入口函数，完成模型的加载，转换及配置
convertModel $SOURCE_MODEL_PATH $TARGET_MODEL_PATH $MODEL_TYPE
