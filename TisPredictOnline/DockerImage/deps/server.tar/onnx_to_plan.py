import tensorrt as trt
import torch
import subprocess
import os
import argparse
import json
import onnx
from types import FunctionType
import logging

logging.basicConfig(level=logging.DEBUG,
                    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S")
logger = logging.getLogger(__name__)

TRT_LOGGER = trt.Logger(trt.Logger.WARNING)
TRT_LOGGER.min_severity = trt.Logger.Severity.INFO


class Onnx2PlanConvertor(object):
    def __init__(self, option):
        self.option = option

    def mark_outputs(self, network):
        last_layer = network.get_layer(network.num_layers-1)
        if not last_layer.num_outputs:
            logger.error("Last layer contains no outputs.")
            return
        for i in range(last_layer.num_outputs):
            network.mark_output(last_layer.get_output(i))

    def check_network(self, network):
        if not network.num_outputs:
            logger.warning("No output nodes found, marking last layer's outputs as network outputs. Correct this if wrong.")
            self.mark_outputs(network)
    
        inputs = [network.get_input(i) for i in range(network.num_inputs)]
        outputs = [network.get_output(i) for i in range(network.num_outputs)]
        max_len = max([len(inp.name) for inp in inputs] + [len(out.name) for out in outputs])

        logger.debug("=== Origin Network Description ===")
        for i, inp in enumerate(inputs):
            logger.debug("Input  {0} | Name: {1:{2}} | Shape: {3}".format(i, inp.name, max_len, inp.shape))
        for i, out in enumerate(outputs):
            logger.debug("Output {0} | Name: {1:{2}} | Shape: {3}".format(i, out.name, max_len, out.shape))

    def add_profiles(self, config, inputs, opt_profiles):
        logger.debug("=== Optimization Profiles ===")
        for i, profile in enumerate(opt_profiles):
            for inp in inputs:
                _min, _opt, _max = profile.get_shape(inp.name)
                logger.debug("{} - OptProfile {} - Min {} Opt {} Max {}".format(inp.name, i, _min, _opt, _max))
            config.add_optimization_profile(profile)

    def create_optimization_profiles(self,builder, inputs, batch_sizes=[1]): 
        # Check if all inputs are fixed explicit batch to create a single profile and avoid duplicates
        if all([inp.shape[0] > -1 for inp in inputs]):
            profile = builder.create_optimization_profile()
            for inp in inputs:
                fbs, shape = inp.shape[0], inp.shape[1:]
                profile.set_shape(inp.name, min=(fbs, *shape), opt=(fbs, *shape), max=(fbs, *shape))
                return [profile]
    
        # Otherwise for mixed fixed+dynamic explicit batch inputs, create several profiles
        profiles = {}
        for bs in batch_sizes:
            if not profiles.get(bs):
                profiles[bs] = builder.create_optimization_profile()

            for inp in inputs: 
                # Check if fixed explicit batch
                if inp.shape[0] > -1:
                    bs = inp.shape[0]
                shape = inp.shape[1:]
                if all(shape[i] > 0 for i in range(len(shape))):
                    shape = shape
                else:
                    for uin in self.option.input_data:
                        if uin["node_name"] == inp.name:
                            shape = uin["dims"][1:]
                            break
                profiles[bs].set_shape(inp.name, min=(bs, *shape), opt=(bs, *shape), max=(bs, *shape))
        return list(profiles.values())

    def update_shape(self, builder, network, config):
        batch_sizes = [1]
        inputs = [network.get_input(i) for i in range(network.num_inputs)]
        opt_profiles = self.create_optimization_profiles(builder, inputs, batch_sizes)
        self.add_profiles(config, inputs, opt_profiles)

    ## build tensorrt model
    def build_engine(self):
        onnx_file_path = self.option.onnx_path
        if not os.path.exists(onnx_file_path):
            quit('ONNX file {} not found'.format(onnx_file_path))

        network_creation_flag = 1 << (int)(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH)        
        with trt.Builder(TRT_LOGGER) as builder, \
                builder.create_network(network_creation_flag) as network, \
                builder.create_builder_config() as config, \
                trt.OnnxParser(network, TRT_LOGGER) as parser:

            #builder.max_batch_size = 1
            logger.debug('Loading ONNX file from path {}...'.format(onnx_file_path))
            with open(onnx_file_path, 'rb') as model:
                logger.debug('Beginning ONNX file parsing')
                parser.parse(model.read())

            config.max_workspace_size = 2**30 # 1GiB

            self.check_network(network)
            self.update_shape(builder, network, config)

            logger.info('Building an engine from file {}; this may take a while...'.format(onnx_file_path))
            engine = builder.build_engine(network,config)
            logger.info("Completed creating Engine")
            return engine

    def convert_onnx_to_plan(self):
        engine = self.build_engine()
        engine_file_path = self.option.out_model_dir + "/model.plan"
        with open(engine_file_path, "wb") as f:
            f.write(engine.serialize())


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config",  default="config.txt",
            help="The shape of model example")
    parser.add_argument("--outpath", default=".")
    option = parser.parse_args()
    convertor = Onnx2PlanConvertor(option)
    convertor.convert_onnx_to_plan()
